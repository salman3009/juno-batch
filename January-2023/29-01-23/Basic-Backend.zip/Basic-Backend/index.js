const express = require('express');
const app = express();

app.get('/newton',(req,res)=>{
      res.send("<html><head></head><body><p>hello world</p></body></html>")
});

app.listen(8080);